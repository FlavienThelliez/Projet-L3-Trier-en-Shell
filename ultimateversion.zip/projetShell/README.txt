Projet de Shell de Pouilly Christopher et Thelliez Flavien
Toutes les fonctions ont �t� implement�es.
Des fichiers de test sont fournis si besoin dans cette archive.
Notre fichier de code shell �tant trishell.sh

-R ne trie pas pas tous les fichiers contenus depuis le repertoire en 1 fois
Il trie repertoire par repertoire comme le ls.
CAD comme dans le cas ci dessous :
(pour trier tous les fichiers entre eux y compris ceux des repertoires, il ne faut pas utiliser
-R mais -R2 sur trishell.sh)

Si on a ces fichiers et que l'on tri avec -n:

test1/
test2/
a.h
b.c
m.o

et dans test1/
c.o
m.h

et dans test2/
z.a
p.q

Cela va renvoyer :

a.h
b.c
m.o
test1/
test2/
Tri dans test1/
test1/c.o
test1/m.h
Tri dans test2/
test2/p.q
test2/z.a

